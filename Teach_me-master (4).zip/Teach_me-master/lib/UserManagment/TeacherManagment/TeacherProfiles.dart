



class TeacherProfiles {



  //
  //  getTeacherDetails(String Subject, String Location)  {
  //
  // }


}