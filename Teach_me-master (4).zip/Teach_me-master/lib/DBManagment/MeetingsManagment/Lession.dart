


class Lesson{

 final String date;
 final String studentphonenumber;
 final String subject;
 final String studentName;
 final String teacherId;
 final String teacherName;
 final String time;
 final String email;

  Lesson(this.date, this.studentName, this.teacherId, this.teacherName, this.time, this.studentphonenumber, this.subject,this.email);






}