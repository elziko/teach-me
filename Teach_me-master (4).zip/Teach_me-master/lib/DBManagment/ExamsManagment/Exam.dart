

class Exam{
  final String examName;
  final String examSubject;
  final List<String> questions;
  final List<List<String>> answers;

  Exam(this.examName, this.examSubject, this.questions, this.answers);







}