





class CourseCategory{

  final String name;
  final int numofCourses;

  CourseCategory(this.name, this.numofCourses);

}
































