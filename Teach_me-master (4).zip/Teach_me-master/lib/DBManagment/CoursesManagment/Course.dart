

class Course{


  final String courseName;
  final String courseSubject;
  final List<String> videosTitles;

  Course(this.courseName, this.courseSubject, this.videosTitles);


}