package com.example.teach_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
