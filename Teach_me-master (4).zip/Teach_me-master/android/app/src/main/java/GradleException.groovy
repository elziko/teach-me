class GradleException {
    GradleException(String s) {
        print(s);
    }
}
