
// test Student class
// Student s = Student(email, password, password, "ameer", "7/11/1996", "05045255662", "haifa", true);
// List<dynamic> details = await s.getTeacherDetails("rfrf", "haifa");
// print("here ------------>>>>>${details}");
// List<dynamic> courseDet=await s.searchForCourses("hebrew");
// print("here->>>>>>>>>>>>>>>>>>>>>>>>>>> ${courseDet}");
// List<dynamic> ExamDet=await s.searchForExams("math");
// print("here->>>>>>>>>>>>>>>>>>>>>>>>>>> ${ExamDet}");
// List<dynamic> MeetingsDet=await s.searchForMeetings("IMAlTCjlTCfMVH0ftk2sdSGhPvv2");
// print("here->>>>>>>>>>>>>>>>>>>>>>>>>>> ${MeetingsDet}");
//--------------------------------------------







// test Teacher class
//   Teacher t = Teacher(email, password, password, "1","1", "1", "1",["sd"],"1");
//   Map<String,dynamic> data={"CourseName":"math4th","CourseSubject":"math","videoTitles":["firstvideo","secondvideo","thirdvideo"]};
//    //await   t.addCourse(data);
// //   print("succesfull");
//   Map<String,dynamic> data1={"Date":"17/11/1885", "StudentId": "IMAlTCjlTCfMVH0ftk2sdSGhPvv2"
//     ,"StudentName"
//     :"ameer",
//     "TeacherId":
//     " 7ezREbRwKCRXQMfOvrqfpuVLxgB3",
//     "TeacherName":
//     "raed",
//     "Time":
//     "21:00"};
//
//  // t.addMeeting(data1);
//  // print("succesfull");
//   Map<String,dynamic> data2={"Date":"17/11/1885", "StudentId": "IMAlTCjlTCfMVH0ftk2sdSGhPvv2"
//     ,"StudentName"
//         :"ameer",
//     "TeacherId":
//     " 7ezREbRwKCRXQMfOvrqfpuVLxgB3",
//     "TeacherName":
//     "raed",
//     "Time":
//     "11:00"};
// //  t.editMeeting(data2, "J6PG7jWOqE5l8IJarc2q");
// //    List<dynamic> listdet = await t.getAllMeetings("IMAlTCjlTCfMVH0ftk2sdSGhPvv2");
// //   for (var i=0; i<listdet.length;i++ ) {
// //    print( "${listdet[i]} \n");
// //     //statements
// //   }
// List<dynamic> stulist=await   t.searchForStudent("saher");
//     for (var i=0; i<stulist.length;i++ ) {
//      print( "${stulist[i]} \n");
//       //statements
//     }